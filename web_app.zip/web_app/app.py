from flask import Flask, render_template, request, send_file
from rdkit import Chem
from rdkit.Chem import Draw
import os

app = Flask(__name__, static_folder='static')

# load model

database = [['COC1=CC=C(C=C1)N2C3=C(CCN(C3=O)C4=CC=C(C=C4)N5CCCCC5=O)C(=N2)C(=O)N',
             'CCOC(=O)c1nn(-c2ccc(OC)cc2)c2c1CCN(c1ccc(N3CCCCC3=O)cc1)C2=O.NC=O',
             'CCOC(=O)c1nn(-c2ccc(OC)cc2)c2c1CCN(c1ccc(N3CCCCC3=O)cc1)C2=O.NC=O',
             'CCOC(=O)c1nn(-c2ccc(OC)cc2)c2c1CCN(c1ccc(N3CCCCC3=O)cc1)C2=O.NC=O',
             0.897506833076477],
            ['COC1=CC=C(C=C1)N2C3=C(CCN(C3=O)C4=CC=C(C=C4)N5CCCCC5=O)C(=N2)C(=O)N',
             'CC(C)=O.NC(=O)c1nn(-c2ccc(O)cc2)c2c1CCN(c1ccc(N3CCCCC3=O)cc1)C2=O',
             'CC(C)=O.NC(=O)c1nn(-c2ccc(O)cc2)c2c1CCN(c1ccc(N3CCCCC3=O)cc1)C2=O',
             'CC(C)=O.NC(=O)c1nn(-c2ccc(O)cc2)c2c1CCN(c1ccc(N3CCCCC3=O)cc1)C2=O',
             'CC(C)=O.NC(=O)c1nn(-c2ccc(O)cc2)c2c1CCN(c1ccc(N3CCCCC3=O)cc1)C2=O',
             0.0784524455666542],
            ['COC1=CC=C(C=C1)N2C3=C(CCN(C3=O)C4=CC=C(C=C4)N5CCCCC5=O)C(=N2)C(=O)N',
             'COc1ccc(-n2nc(C(N)=O)c3c2C(=O)N(c2ccc(I)cc2)CC3)cc1.O=C1CCCCN1',
             'COc1ccc(-n2nc(C(N)=O)c3c2C(=O)NCC3)cc1.O=C1CCCCN1c1ccc(I)cc1',
             0.0059763896279037]]


def getSmiles(database):
    target = database[0][0]
    smiles_list = [item[1:-1] for item in database]
    scores_list = [item[-1] for item in database]
    return target, smiles_list, scores_list


def getPictures(target, smiles_list):
    img_path1 = []
    img_path2 = []
    img_path3 = []
    Draw.MolToImage(Chem.MolFromSmiles(target)).save('./static/target.jpg')
    for i in range(len(smiles_list)):
        path = "./static/Solution" + str(i + 1)
        if not os.path.exists(path):
            os.makedirs(path)
            print("Folder created")
        else:
            print("Folder already exists")
        for j in range(len(smiles_list[i])):
            Draw.MolToImage(Chem.MolFromSmiles(smiles_list[i][j])).save(
                path + '/img' + str(j + 1) + '.jpg')
    for i in range(len(smiles_list)):
        for j in range(len(smiles_list[i])):
            if i == 0:
                img_path1.append('Solution1/img' + str(j + 1) + '.jpg')
            elif i == 1:
                img_path2.append('Solution2/img' + str(j + 1) + '.jpg')
            elif i == 2:
                img_path3.append('Solution3/img' + str(j + 1) + '.jpg')
    return img_path1, img_path2, img_path3


# target, smiles_list, scores_list = getSmiles(database)
# getPictures(target, smiles_list)



@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == "POST":
        Smiles = request.form.get('Smiles') # Capture text input data
        print(Smiles)
        # 调用模型得到database
        target, smiles_list, scores_list = getSmiles(database)
        image_paths1, image_paths2, image_paths3 = getPictures(target, smiles_list)
        return render_template('result.html', target=target, smiles_list=smiles_list, scores_list=scores_list,
                               image_paths1=image_paths1, image_paths2=image_paths2, image_paths3=image_paths3)
    return render_template('Index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)
